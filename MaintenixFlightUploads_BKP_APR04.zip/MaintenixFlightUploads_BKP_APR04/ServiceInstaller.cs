﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace MaintenixFlightUploads
{
    [RunInstaller(true)]
    public class ServiceInstaller : Installer
    {
        private string ServiceName;
        private string DisplayName;
        private ServiceStartMode StartType;
        private MaintenixFlightUploadService maintenixFlightUploadService1;
        private string Description;

        public ServiceInstaller()
        {
            ServiceProcessInstaller serviceProcessInstaller = new ServiceProcessInstaller();
            ServiceInstaller serviceInstaller = new ServiceInstaller();

            // Setup the Service Account type per your requirement
            serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
            serviceProcessInstaller.Username = null;
            serviceProcessInstaller.Password = null;

            serviceInstaller.ServiceName = "Service";
            serviceInstaller.DisplayName = "Windows Service";
            serviceInstaller.StartType = ServiceStartMode.Automatic;
            serviceInstaller.Description = "My custom hybrid service";

            this.Installers.Add(serviceProcessInstaller);
            this.Installers.Add(serviceInstaller);
        }

        private void InitializeComponent()
        {
            this.maintenixFlightUploadService1 = new MaintenixFlightUploadService();
            // 
            // maintenixFlightUploadService1
            // 
            this.maintenixFlightUploadService1.ExitCode = 0;
            this.maintenixFlightUploadService1.ServiceName = "Service1";

        }
    }
}  
